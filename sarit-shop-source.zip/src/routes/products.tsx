import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { useStore } from "@/lib/store";
import { useState, useMemo } from "react";
import { Search } from "lucide-react";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Products — Sarit Shop" },
      { name: "description", content: "Phones, SIM cards, routers and Safaricom devices at Sarit Shop, Nairobi." },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const [products] = useStore("products");
  const [q, setQ] = useState("");
  const filtered = useMemo(
    () => products.filter((p) => (p.name + p.description).toLowerCase().includes(q.toLowerCase())),
    [products, q]
  );

  return (
    <SiteLayout>
      <section className="bg-gradient-to-b from-secondary/50 to-background py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 animate-fade-in">
          <h1 className="text-4xl sm:text-5xl font-bold text-center">Our Products</h1>
          <p className="mt-4 text-muted-foreground text-center max-w-2xl mx-auto">
            Genuine Safaricom devices and accessories.
          </p>
          <div className="mt-8 max-w-md mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search products..."
              className="w-full pl-11 pr-4 py-3 rounded-xl border border-border bg-card focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-24">
        {filtered.length === 0 ? (
          <p className="text-center text-muted-foreground py-20">No products match your search.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((p) => (
              <article key={p.id} className="bg-card rounded-2xl overflow-hidden border border-border hover:shadow-elegant transition-all hover:-translate-y-1 animate-fade-in">
                <div className="aspect-square overflow-hidden bg-muted">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" />
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-lg">{p.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{p.description}</p>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-primary font-bold text-lg">{p.price}</span>
                    <button className="px-3 py-1.5 text-sm rounded-lg bg-primary text-primary-foreground hover:bg-primary-glow transition-colors">
                      Enquire
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </SiteLayout>
  );
}
