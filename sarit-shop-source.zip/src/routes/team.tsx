import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout as Layout } from "@/components/site/Layout";
import { useStore, TEAM_CATEGORIES, type TeamCategory } from "@/lib/store";
import { Crown, Users, Megaphone, ChefHat, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Our Team — Sarit Shop" },
      { name: "description", content: "Meet the Sarit Shop team — managers, team leaders, brand ambassadors, kitchen staff, and security." },
      { property: "og:title", content: "Our Team — Sarit Shop" },
      { property: "og:description", content: "The people behind Sarit Shop in Nairobi." },
    ],
  }),
  component: TeamPage,
});

const ICONS: Record<TeamCategory, React.ComponentType<{ className?: string }>> = {
  "Manager": Crown,
  "Team Leader": Users,
  "Brand Ambassador": Megaphone,
  "Kitchen Staff": ChefHat,
  "Security": ShieldCheck,
};

function TeamPage() {
  const [team] = useStore("team");
  return (
    <Layout>
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center animate-fade-in">
          <h1 className="text-4xl sm:text-5xl font-bold">Meet Our Team</h1>
          <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
            The friendly people who make Sarit Shop run every day — from the front desk to the kitchen and security.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-16">
        {TEAM_CATEGORIES.map((cat) => {
          const members = team.filter((m) => m.category === cat);
          if (members.length === 0) return null;
          const Icon = ICONS[cat];
          return (
            <section key={cat} className="animate-fade-in">
              <div className="flex items-center gap-3 mb-6">
                <span className="size-11 grid place-items-center rounded-xl bg-primary text-primary-foreground">
                  <Icon className="size-5" />
                </span>
                <div>
                  <h2 className="text-2xl font-bold">{cat}{cat !== "Security" && cat !== "Kitchen Staff" ? "s" : ""}</h2>
                  <p className="text-sm text-muted-foreground">{members.length} member{members.length > 1 ? "s" : ""}</p>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {members.map((m) => (
                  <article key={m.id} className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-elegant hover:-translate-y-1 transition-all">
                    <img src={m.image} alt={m.name} className="w-full aspect-[4/3] object-cover" />
                    <div className="p-5">
                      <h3 className="font-bold text-lg">{m.name}</h3>
                      <p className="text-sm text-primary font-medium">{m.role}</p>
                      {m.description && <p className="text-sm text-muted-foreground mt-3">{m.description}</p>}
                    </div>
                  </article>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </Layout>
  );
}
