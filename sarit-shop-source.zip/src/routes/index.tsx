import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { useStore } from "@/lib/store";
import { Wallet, Zap, Headphones, ArrowRight, Smartphone, Shield, Star } from "lucide-react";
import hero from "@/assets/hero-shop.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sarit Shop — Your Trusted Safaricom Partner in Nairobi" },
      { name: "description", content: "Sarit Shop at Sarit Centre Nairobi offers M-Pesa, SIM registration, data bundles, phones and Safaricom support." },
      { property: "og:title", content: "Sarit Shop — Trusted Safaricom Partner" },
      { property: "og:description", content: "M-Pesa, SIM, bundles, phones and support at Sarit Centre, Nairobi." },
    ],
  }),
  component: Home,
});

function Home() {
  const [products] = useStore("products");
  const [gallery] = useStore("gallery");

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative min-h-[88vh] flex items-center overflow-hidden">
        <img src={hero} alt="Sarit Shop storefront" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 text-white animate-fade-in">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-primary/90 mb-5">
            Official Safaricom Dealer · Sarit Centre
          </span>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight max-w-3xl leading-[1.05]">
            Welcome to Sarit Shop —<br />
            <span className="text-primary-glow">Your Trusted Safaricom Partner</span>
          </h1>
          <p className="mt-6 text-lg sm:text-xl max-w-2xl opacity-90">
            M-Pesa, SIM registration, blazing-fast data bundles, the latest phones and friendly support — all under one roof.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/services" className="px-6 py-3 rounded-lg bg-primary hover:bg-primary-glow font-semibold shadow-elegant transition-all hover:-translate-y-0.5">
              Get Service Now
            </Link>
            <Link to="/contact" className="px-6 py-3 rounded-lg border-2 border-white/40 hover:bg-white/10 font-semibold transition-colors">
              Visit Us →
            </Link>
          </div>
        </div>
      </section>

      {/* QUICK SERVICES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold">Everything you need, in one stop</h2>
          <p className="mt-3 text-muted-foreground">Quick access to our most popular services.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { icon: Wallet, title: "M-Pesa", desc: "Deposit, withdraw and send money fast." },
            { icon: Smartphone, title: "SIM Registration", desc: "New lines and SIM replacements." },
            { icon: Zap, title: "Data Bundles", desc: "All Safaricom bundles & airtime." },
            { icon: Shield, title: "Genuine Devices", desc: "Authorized Safaricom products only." },
            { icon: Headphones, title: "Expert Support", desc: "Friendly help, every visit." },
            { icon: Star, title: "Trusted by Nairobi", desc: "Thousands of happy customers." },
          ].map((s, i) => (
            <div key={i} className="group p-6 rounded-2xl border border-border bg-card hover:shadow-elegant transition-all hover:-translate-y-1">
              <div className="size-12 rounded-xl bg-gradient-to-br from-primary to-primary-glow text-primary-foreground grid place-items-center mb-4 group-hover:scale-110 transition-transform">
                <s.icon className="size-6" />
              </div>
              <h3 className="font-semibold text-lg">{s.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="bg-secondary/40 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-10">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold">Featured Products</h2>
              <p className="mt-2 text-muted-foreground">Latest devices and Safaricom essentials.</p>
            </div>
            <Link to="/products" className="hidden sm:inline-flex items-center gap-1 text-primary font-semibold hover:gap-2 transition-all">
              View all <ArrowRight className="size-4" />
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.slice(0, 4).map((p) => (
              <div key={p.id} className="bg-card rounded-2xl overflow-hidden border border-border hover:shadow-elegant transition-all hover:-translate-y-1">
                <div className="aspect-square overflow-hidden bg-muted">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold">{p.name}</h3>
                  <p className="text-primary font-bold mt-1">{p.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-20">
        <h2 className="text-3xl sm:text-4xl font-bold text-center">What our customers say</h2>
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          {[
            { q: "Fast M-Pesa service, never long queues!", n: "Mary K." },
            { q: "Got my new SIM in 5 minutes. Excellent.", n: "James O." },
            { q: "Best place for genuine phones in Sarit.", n: "Faith N." },
          ].map((t, i) => (
            <div key={i} className="p-6 rounded-2xl bg-card border border-border">
              <div className="flex gap-1 text-primary mb-3">
                {Array.from({ length: 5 }).map((_, j) => <Star key={j} className="size-4 fill-current" />)}
              </div>
              <p className="text-foreground/90">"{t.q}"</p>
              <p className="mt-4 text-sm font-semibold text-muted-foreground">— {t.n}</p>
            </div>
          ))}
        </div>
      </section>

      {/* GALLERY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-10">Inside the shop</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {gallery.map((g) => (
            <div key={g.id} className="aspect-[4/3] rounded-xl overflow-hidden group relative">
              <img src={g.url} alt={g.caption} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                <span className="text-white font-semibold">{g.caption}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
        <div className="rounded-3xl p-10 sm:p-16 text-center text-primary-foreground shadow-elegant" style={{ background: "var(--gradient-primary)" }}>
          <h2 className="text-3xl sm:text-4xl font-bold">Ready to be served the Sarit way?</h2>
          <p className="mt-3 opacity-90">Walk in today or reach out and we'll be happy to help.</p>
          <Link to="/contact" className="inline-block mt-6 px-8 py-3 rounded-lg bg-white text-primary font-semibold hover:scale-105 transition-transform">
            Contact Us
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
