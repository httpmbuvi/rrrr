import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { isLoggedIn, login, logout, useStore, uid, fileToDataUrl, ADMIN_USER, ADMIN_PASS } from "@/lib/store";
import { LogOut, Trash2, Plus, Upload, ShieldCheck, Package, Wrench, Users, Image as ImageIcon, MessageSquare } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — Sarit Shop" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

function AdminPage() {
  const [auth, setAuth] = useState(false);
  useEffect(() => { setAuth(isLoggedIn()); }, []);
  if (!auth) return <LoginScreen onLogin={() => setAuth(true)} />;
  return <Dashboard onLogout={() => { logout(); setAuth(false); }} />;
}

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(u, p)) onLogin();
    else setErr("Invalid credentials");
  };
  return (
    <div className="min-h-screen grid place-items-center bg-gradient-to-br from-primary/10 via-background to-background px-4">
      <form onSubmit={submit} className="w-full max-w-md p-8 rounded-2xl bg-card border border-border shadow-elegant animate-scale-in">
        <div className="size-14 rounded-xl bg-primary text-primary-foreground grid place-items-center mx-auto mb-4">
          <ShieldCheck className="size-7" />
        </div>
        <h1 className="text-2xl font-bold text-center">Admin Login</h1>
        <p className="text-sm text-muted-foreground text-center mt-1">Sarit Shop control panel</p>
        <div className="mt-6 space-y-3">
          <input value={u} onChange={(e) => setU(e.target.value)} placeholder="Username" className="w-full px-4 py-2.5 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary focus:outline-none" />
          <input value={p} onChange={(e) => setP(e.target.value)} type="password" placeholder="Password" className="w-full px-4 py-2.5 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary focus:outline-none" />
          {err && <p className="text-sm text-destructive">{err}</p>}
          <button className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:bg-primary-glow transition-colors">Sign In</button>
          <p className="text-xs text-muted-foreground text-center mt-2">
            Demo: <strong>{ADMIN_USER}</strong> / <strong>{ADMIN_PASS}</strong>
          </p>
        </div>
      </form>
    </div>
  );
}

const TABS = [
  { id: "overview", label: "Overview", icon: ShieldCheck },
  { id: "products", label: "Products", icon: Package },
  { id: "services", label: "Services", icon: Wrench },
  { id: "team", label: "Team", icon: Users },
  { id: "gallery", label: "Gallery", icon: ImageIcon },
  { id: "messages", label: "Messages", icon: MessageSquare },
] as const;

function Dashboard({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("overview");
  const [products] = useStore("products");
  const [services] = useStore("services");
  const [messages] = useStore("messages");

  return (
    <div className="min-h-screen bg-secondary/30">
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <h1 className="font-bold text-lg">Sarit Admin</h1>
          <button onClick={onLogout} className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-destructive">
            <LogOut className="size-4" /> Logout
          </button>
        </div>
      </header>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 grid lg:grid-cols-[220px_1fr] gap-8">
        <aside className="space-y-1">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${tab === t.id ? "bg-primary text-primary-foreground" : "hover:bg-accent"}`}>
              <t.icon className="size-4" /> {t.label}
            </button>
          ))}
        </aside>
        <section>
          {tab === "overview" && (
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { label: "Products", value: products.length, icon: Package },
                { label: "Services", value: services.length, icon: Wrench },
                { label: "Messages", value: messages.length, icon: MessageSquare },
              ].map((s, i) => (
                <div key={i} className="p-6 rounded-2xl bg-card border border-border">
                  <s.icon className="size-8 text-primary mb-3" />
                  <p className="text-3xl font-bold">{s.value}</p>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          )}
          {tab === "products" && <ProductsAdmin />}
          {tab === "services" && <ServicesAdmin />}
          {tab === "team" && <TeamAdmin />}
          {tab === "gallery" && <GalleryAdmin />}
          {tab === "messages" && <MessagesAdmin />}
        </section>
      </div>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="p-6 rounded-2xl bg-card border border-border">{children}</div>;
}

async function pickImage(e: React.ChangeEvent<HTMLInputElement>): Promise<string | null> {
  const f = e.target.files?.[0];
  if (!f) return null;
  if (f.size > 10 * 1024 * 1024) { alert("Max 10MB"); return null; }
  if (!["image/jpeg", "image/png", "image/webp"].includes(f.type)) { alert("Use JPG, PNG, or WebP"); return null; }
  return await fileToDataUrl(f);
}

function ProductsAdmin() {
  const [items, set] = useStore("products");
  const [draft, setDraft] = useState({ name: "", price: "", description: "", image: "" });
  const add = () => {
    if (!draft.name) return;
    set([{ id: uid(), ...draft, image: draft.image || "https://placehold.co/600x600?text=Product" }, ...items]);
    setDraft({ name: "", price: "", description: "", image: "" });
  };
  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-bold text-lg mb-4">Add Product</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <input placeholder="Name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background" />
          <input placeholder="Price (e.g. KSh 1,000)" value={draft.price} onChange={(e) => setDraft({ ...draft, price: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background" />
          <textarea placeholder="Description" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background sm:col-span-2" rows={2} />
          <label className="sm:col-span-2 flex items-center gap-3 px-3 py-2 rounded-lg border border-dashed border-border bg-background cursor-pointer hover:bg-accent">
            <Upload className="size-4" />
            <span className="text-sm">{draft.image ? "Image selected" : "Upload image (JPG/PNG/WebP, ≤10MB)"}</span>
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={async (e) => { const url = await pickImage(e); if (url) setDraft({ ...draft, image: url }); }} />
          </label>
          {draft.image && <img src={draft.image} alt="" className="size-24 rounded-lg object-cover" />}
        </div>
        <button onClick={add} className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground font-semibold"><Plus className="size-4" /> Add Product</button>
      </Card>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((p) => (
          <div key={p.id} className="rounded-2xl border border-border bg-card overflow-hidden">
            <img src={p.image} alt={p.name} className="w-full aspect-square object-cover" />
            <div className="p-4">
              <p className="font-semibold">{p.name}</p>
              <p className="text-primary font-bold text-sm">{p.price}</p>
              <button onClick={() => set(items.filter((x) => x.id !== p.id))} className="mt-3 inline-flex items-center gap-1 text-sm text-destructive hover:underline">
                <Trash2 className="size-3.5" /> Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ServicesAdmin() {
  const [items, set] = useStore("services");
  const [draft, setDraft] = useState({ title: "", description: "", icon: "Wallet" });
  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-bold text-lg mb-4">Add Service</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <input placeholder="Title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background" />
          <select value={draft.icon} onChange={(e) => setDraft({ ...draft, icon: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background">
            {["Wallet", "Zap", "Headphones", "SimCard", "Shield", "Signal"].map((i) => <option key={i}>{i}</option>)}
          </select>
          <textarea placeholder="Description" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background sm:col-span-2" rows={2} />
        </div>
        <button onClick={() => { if (!draft.title) return; set([{ id: uid(), ...draft }, ...items]); setDraft({ title: "", description: "", icon: "Wallet" }); }}
          className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground font-semibold">
          <Plus className="size-4" /> Add Service
        </button>
      </Card>
      <div className="grid sm:grid-cols-2 gap-4">
        {items.map((s) => (
          <div key={s.id} className="p-5 rounded-2xl border border-border bg-card">
            <p className="font-bold">{s.title}</p>
            <p className="text-sm text-muted-foreground mt-1">{s.description}</p>
            <button onClick={() => set(items.filter((x) => x.id !== s.id))} className="mt-3 inline-flex items-center gap-1 text-sm text-destructive hover:underline">
              <Trash2 className="size-3.5" /> Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function TeamAdmin() {
  const [items, set] = useStore("team");
  const [draft, setDraft] = useState({ name: "", role: "", image: "", category: "Manager" as import("@/lib/store").TeamCategory, description: "" });
  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-bold text-lg mb-4">Add Team Member</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <input placeholder="Name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background" />
          <input placeholder="Role / Title" value={draft.role} onChange={(e) => setDraft({ ...draft, role: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background" />
          <select value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value as import("@/lib/store").TeamCategory })} className="px-3 py-2 rounded-lg border border-border bg-background sm:col-span-2">
            {(["Manager","Team Leader","Brand Ambassador","Kitchen Staff","Security"] as const).map((c) => <option key={c}>{c}</option>)}
          </select>
          <textarea placeholder="Description" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} className="px-3 py-2 rounded-lg border border-border bg-background sm:col-span-2" rows={2} />
          <label className="sm:col-span-2 flex items-center gap-3 px-3 py-2 rounded-lg border border-dashed border-border bg-background cursor-pointer hover:bg-accent">
            <Upload className="size-4" />
            <span className="text-sm">{draft.image ? "Image selected" : "Upload photo"}</span>
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={async (e) => { const url = await pickImage(e); if (url) setDraft({ ...draft, image: url }); }} />
          </label>
          {draft.image && <img src={draft.image} alt="" className="size-24 rounded-full object-cover" />}
        </div>
        <button onClick={() => { if (!draft.name) return; set([{ id: uid(), ...draft, image: draft.image || "https://placehold.co/200" }, ...items]); setDraft({ name: "", role: "", image: "", category: "Manager", description: "" }); }}
          className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground font-semibold">
          <Plus className="size-4" /> Add Member
        </button>
      </Card>
      <div className="grid sm:grid-cols-3 gap-4">
        {items.map((m) => (
          <div key={m.id} className="p-5 rounded-2xl border border-border bg-card text-center">
            <img src={m.image} alt={m.name} className="size-24 mx-auto rounded-full object-cover" />
            <p className="mt-3 font-bold">{m.name}</p>
            <p className="text-sm text-primary">{m.role}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{m.category}</p>
            {m.description && <p className="text-xs text-muted-foreground mt-2">{m.description}</p>}
            <button onClick={() => set(items.filter((x) => x.id !== m.id))} className="mt-3 inline-flex items-center gap-1 text-sm text-destructive hover:underline">
              <Trash2 className="size-3.5" /> Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function GalleryAdmin() {
  const [items, set] = useStore("gallery");
  const [caption, setCaption] = useState("");
  const upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = await pickImage(e);
    if (!url) return;
    set([{ id: uid(), url, caption: caption || "Sarit Shop" }, ...items]);
    setCaption("");
  };
  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-bold text-lg mb-4">Upload to Gallery</h2>
        <div className="flex flex-col sm:flex-row gap-3">
          <input placeholder="Caption (optional)" value={caption} onChange={(e) => setCaption(e.target.value)} className="flex-1 px-3 py-2 rounded-lg border border-border bg-background" />
          <label className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground font-semibold cursor-pointer">
            <Upload className="size-4" /> Choose Image
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={upload} />
          </label>
        </div>
      </Card>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((g) => (
          <div key={g.id} className="rounded-2xl border border-border bg-card overflow-hidden">
            <img src={g.url} alt={g.caption} className="w-full aspect-[4/3] object-cover" />
            <div className="p-3 flex items-center justify-between">
              <p className="text-sm font-medium">{g.caption}</p>
              <button onClick={() => set(items.filter((x) => x.id !== g.id))} className="text-destructive hover:text-destructive/80">
                <Trash2 className="size-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MessagesAdmin() {
  const [items, set] = useStore("messages");
  if (items.length === 0) return <Card><p className="text-muted-foreground text-center py-8">No messages yet.</p></Card>;
  return (
    <div className="space-y-3">
      {items.map((m) => (
        <Card key={m.id}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <p className="font-bold">{m.name} <span className="text-sm text-muted-foreground font-normal">· {m.email}</span></p>
              <p className="text-xs text-muted-foreground mt-0.5">{new Date(m.createdAt).toLocaleString()}</p>
              <p className="mt-3">{m.message}</p>
            </div>
            <button onClick={() => set(items.filter((x) => x.id !== m.id))} className="text-destructive hover:text-destructive/80">
              <Trash2 className="size-4" />
            </button>
          </div>
        </Card>
      ))}
    </div>
  );
}
