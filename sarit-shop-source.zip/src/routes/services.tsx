import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { useStore } from "@/lib/store";
import { Wallet, Zap, Headphones, Smartphone, Signal, Shield } from "lucide-react";

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Wallet, Zap, Headphones, SimCard: Smartphone, Signal, Shield,
};

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Sarit Shop" },
      { name: "description", content: "M-Pesa, SIM registration, data bundles and Safaricom customer support at Sarit Centre, Nairobi." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const [services] = useStore("services");
  return (
    <SiteLayout>
      <section className="bg-gradient-to-b from-secondary/50 to-background py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center animate-fade-in">
          <h1 className="text-4xl sm:text-5xl font-bold">Our Services</h1>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Full range of Safaricom services delivered with speed and care.
          </p>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-24">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => {
            const Icon = ICONS[s.icon] || Signal;
            return (
              <div key={s.id} className="p-8 rounded-2xl border border-border bg-card hover:shadow-elegant transition-all hover:-translate-y-1 group">
                <div className="size-14 rounded-xl bg-gradient-to-br from-primary to-primary-glow text-primary-foreground grid place-items-center mb-5 group-hover:scale-110 transition-transform">
                  <Icon className="size-7" />
                </div>
                <h3 className="text-xl font-bold">{s.title}</h3>
                <p className="mt-2 text-muted-foreground">{s.description}</p>
              </div>
            );
          })}
        </div>
      </section>
    </SiteLayout>
  );
}
