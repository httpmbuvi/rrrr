import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { useStore } from "@/lib/store";
import { Target, Eye, MapPin } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Sarit Shop" },
      { name: "description", content: "Sarit Shop is a trusted Safaricom dealer at Sarit Centre, Nairobi, dedicated to fast, friendly service." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const [team] = useStore("team");
  return (
    <SiteLayout>
      <section className="bg-gradient-to-b from-secondary/50 to-background py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center animate-fade-in">
          <h1 className="text-4xl sm:text-5xl font-bold">About Sarit Shop</h1>
          <p className="mt-5 text-lg text-muted-foreground">
            We're a Safaricom-authorized partner based at Sarit Centre, Nairobi, offering the full Safaricom
            experience — from M-Pesa transactions to the newest devices — backed by people who genuinely care.
          </p>
          <p className="mt-3 inline-flex items-center gap-2 text-primary font-semibold">
            <MapPin className="size-4" /> Sarit Centre, Westlands, Nairobi
          </p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16 grid md:grid-cols-2 gap-6">
        <div className="p-8 rounded-2xl border border-border bg-card">
          <Target className="size-10 text-primary mb-4" />
          <h2 className="text-2xl font-bold">Our Mission</h2>
          <p className="mt-3 text-muted-foreground">
            To deliver fast, reliable and friendly Safaricom services that connect every Kenyan to the
            people, services and opportunities that matter.
          </p>
        </div>
        <div className="p-8 rounded-2xl border border-border bg-card">
          <Eye className="size-10 text-primary mb-4" />
          <h2 className="text-2xl font-bold">Our Vision</h2>
          <p className="mt-3 text-muted-foreground">
            To be Nairobi's most trusted neighborhood Safaricom shop — where every customer leaves
            smiling and connected.
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-24">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">Meet the team</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {team.map((m) => (
            <div key={m.id} className="text-center p-6 rounded-2xl bg-card border border-border hover:shadow-elegant transition-all hover:-translate-y-1">
              <img src={m.image} alt={m.name} className="size-32 mx-auto rounded-full object-cover ring-4 ring-primary/20" />
              <h3 className="mt-4 font-bold text-lg">{m.name}</h3>
              <p className="text-primary text-sm font-medium">{m.role}</p>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
