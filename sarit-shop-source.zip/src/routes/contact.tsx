import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { addMessage } from "@/lib/store";
import { useState } from "react";
import { Mail, Phone, MapPin, Send, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Sarit Shop" },
      { name: "description", content: "Visit Sarit Shop at Sarit Centre Nairobi, call or send us a message." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) return;
    addMessage(form);
    setSent(true);
    setForm({ name: "", email: "", message: "" });
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <SiteLayout>
      <section className="bg-gradient-to-b from-secondary/50 to-background py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center animate-fade-in">
          <h1 className="text-4xl sm:text-5xl font-bold">Get in Touch</h1>
          <p className="mt-4 text-muted-foreground">We'd love to hear from you. Reach out anytime.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-24 grid lg:grid-cols-2 gap-10">
        <div className="space-y-6">
          {[
            { icon: MapPin, label: "Visit", value: "Sarit Centre, Westlands, Nairobi" },
            { icon: Phone, label: "Call", value: "+254 700 000 000" },
            { icon: Mail, label: "Email", value: "hello@saritshop.co.ke" },
          ].map((c, i) => (
            <div key={i} className="flex gap-4 p-5 rounded-2xl bg-card border border-border">
              <div className="size-12 rounded-xl bg-primary/10 text-primary grid place-items-center shrink-0">
                <c.icon className="size-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{c.label}</p>
                <p className="font-semibold">{c.value}</p>
              </div>
            </div>
          ))}
          <div className="rounded-2xl overflow-hidden border border-border aspect-video">
            <iframe
              title="Sarit Centre map"
              src="https://www.google.com/maps?q=Sarit+Centre+Nairobi&output=embed"
              className="w-full h-full"
              loading="lazy"
            />
          </div>
        </div>

        <form onSubmit={submit} className="p-8 rounded-2xl bg-card border border-border space-y-4 h-fit shadow-elegant">
          <h2 className="text-2xl font-bold">Send us a message</h2>
          <div>
            <label className="text-sm font-medium">Name</label>
            <input
              required maxLength={100}
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="mt-1 w-full px-4 py-2.5 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary focus:outline-none"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Email</label>
            <input
              required type="email" maxLength={255}
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="mt-1 w-full px-4 py-2.5 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary focus:outline-none"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Message</label>
            <textarea
              required maxLength={1000} rows={5}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="mt-1 w-full px-4 py-2.5 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary focus:outline-none resize-none"
            />
          </div>
          <button type="submit" className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:bg-primary-glow transition-colors">
            <Send className="size-4" /> Send Message
          </button>
          {sent && (
            <div className="flex items-center gap-2 text-primary text-sm animate-fade-in">
              <CheckCircle2 className="size-4" /> Message sent — we'll get back to you soon!
            </div>
          )}
        </form>
      </section>
    </SiteLayout>
  );
}
