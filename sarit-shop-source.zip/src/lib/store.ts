// Simple localStorage-backed store for admin-managed content
import { useEffect, useState } from "react";

export type Product = { id: string; name: string; price: string; description: string; image: string };
export type Service = { id: string; title: string; description: string; icon: string };
export type TeamCategory = "Manager" | "Team Leader" | "Brand Ambassador" | "Kitchen Staff" | "Security";
export const TEAM_CATEGORIES: TeamCategory[] = ["Manager", "Team Leader", "Brand Ambassador", "Kitchen Staff", "Security"];
export type TeamMember = { id: string; name: string; role: string; image: string; category: TeamCategory; description?: string };
export type GalleryImage = { id: string; url: string; caption: string };
export type Message = { id: string; name: string; email: string; message: string; createdAt: string };

const KEYS = {
  products: "sarit:products",
  services: "sarit:services",
  team: "sarit:team",
  gallery: "sarit:gallery",
  messages: "sarit:messages",
  auth: "sarit:auth",
} as const;

export const DEFAULTS = {
  products: [
    { id: "p1", name: "Samsung Galaxy A15", price: "KSh 18,500", description: "6.5'' display, 128GB storage, 50MP camera.", image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80" },
    { id: "p2", name: "Safaricom 4G Router", price: "KSh 6,999", description: "Portable mobile WiFi, up to 10 devices.", image: "https://images.unsplash.com/photo-1606904825846-647eb07f5be2?w=800&q=80" },
    { id: "p3", name: "Safaricom SIM Card", price: "KSh 100", description: "New line registration with free starter bundle.", image: "https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&q=80" },
    { id: "p4", name: "iPhone 13", price: "KSh 89,000", description: "128GB, midnight blue, brand new sealed.", image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=800&q=80" },
  ] as Product[],
  services: [
    { id: "s1", title: "M-Pesa Services", description: "Deposit, withdraw, and send money instantly.", icon: "Wallet" },
    { id: "s2", title: "SIM Registration", description: "New SIM cards and replacements done in minutes.", icon: "SimCard" },
    { id: "s3", title: "Airtime & Bundles", description: "Top up and grab the best data offers.", icon: "Zap" },
    { id: "s4", title: "Customer Support", description: "Friendly help with all your Safaricom needs.", icon: "Headphones" },
  ] as Service[],
  team: [
    { id: "t1", name: "Brian Otieno", role: "Shop Manager", category: "Manager", description: "Oversees daily operations, staff scheduling, and customer experience at Sarit Shop. Brian has 8+ years in retail telecom management.", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80" },
    { id: "t2", name: "Aisha Wanjiru", role: "Sales Team Leader", category: "Team Leader", description: "Leads the sales floor and M-Pesa counter team, ensuring smooth customer journeys.", image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400&q=80" },
    { id: "t3", name: "Kevin Mwangi", role: "Tech Team Leader", category: "Team Leader", description: "Supervises device setup, repairs, and tech support specialists.", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80" },
    { id: "t4", name: "Mercy Achieng", role: "Brand Ambassador", category: "Brand Ambassador", description: "Champions Safaricom promotions and engages customers with the latest offers.", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&q=80" },
    { id: "t5", name: "Joseph Kamau", role: "Brand Ambassador", category: "Brand Ambassador", description: "Drives outreach activations and product demos around Sarit Centre.", image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=400&q=80" },
    { id: "t6", name: "Grace Njeri", role: "Head Chef", category: "Kitchen Staff", description: "Runs the staff kitchen and customer refreshments bar with a warm, local menu.", image: "https://images.unsplash.com/photo-1607631568010-a87245c0daf8?w=400&q=80" },
    { id: "t7", name: "Peter Omondi", role: "Kitchen Assistant", category: "Kitchen Staff", description: "Supports food prep and keeps the refreshment area spotless.", image: "https://images.unsplash.com/photo-1581349485608-9469926a8e5e?w=400&q=80" },
    { id: "t8", name: "Samuel Kiprono", role: "Head of Security", category: "Security", description: "Leads the security team safeguarding customers, staff, and stock 24/7.", image: "https://images.unsplash.com/photo-1521119989659-a83eee488004?w=400&q=80" },
    { id: "t9", name: "Daniel Mutiso", role: "Security Officer", category: "Security", description: "Manages access control and customer assistance at the main entrance.", image: "https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?w=400&q=80" },
  ] as TeamMember[],
  gallery: [
    { id: "g1", url: "https://images.unsplash.com/photo-1556656793-08538906a9f8?w=800&q=80", caption: "Shop front" },
    { id: "g2", url: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800&q=80", caption: "Customer service" },
    { id: "g3", url: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&q=80", caption: "Phone display" },
  ] as GalleryImage[],
  messages: [] as Message[],
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent("sarit:store", { detail: key }));
}

export function useStore<K extends keyof typeof DEFAULTS>(name: K) {
  type T = (typeof DEFAULTS)[K];
  const key = KEYS[name];
  const fallback = DEFAULTS[name] as T;
  const [data, setData] = useState<T>(() => read<T>(key, fallback));

  useEffect(() => {
    const sync = () => setData(read<T>(key, fallback));
    sync();
    window.addEventListener("sarit:store", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("sarit:store", sync);
      window.removeEventListener("storage", sync);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, name]);

  const update = (next: T) => {
    write(key, next);
    setData(next);
  };
  return [data, update] as const;
}

export const ADMIN_USER = "admin";
export const ADMIN_PASS = "sarit123";

export function isLoggedIn() {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(KEYS.auth) === "1";
}
export function login(u: string, p: string) {
  if (u === ADMIN_USER && p === ADMIN_PASS) {
    localStorage.setItem(KEYS.auth, "1");
    return true;
  }
  return false;
}
export function logout() {
  localStorage.removeItem(KEYS.auth);
}

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result as string);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

export function addMessage(m: Omit<Message, "id" | "createdAt">) {
  const list = read<Message[]>(KEYS.messages, []);
  list.unshift({ ...m, id: uid(), createdAt: new Date().toISOString() });
  write(KEYS.messages, list);
}
