import { Link } from "@tanstack/react-router";
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin, Signal } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-foreground text-background mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-bold text-lg mb-3">
            <span className="grid place-items-center size-9 rounded-lg bg-primary text-primary-foreground">
              <Signal className="size-5" />
            </span>
            Sarit Shop
          </div>
          <p className="text-sm opacity-70 leading-relaxed">
            Your trusted Safaricom partner at Sarit Centre, Nairobi. Serving customers with care since day one.
          </p>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Quick Links</h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li><Link to="/services" className="hover:text-primary-glow">Services</Link></li>
            <li><Link to="/products" className="hover:text-primary-glow">Products</Link></li>
            <li><Link to="/about" className="hover:text-primary-glow">About Us</Link></li>
            <li><Link to="/contact" className="hover:text-primary-glow">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Contact</h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li className="flex items-center gap-2"><MapPin className="size-4" /> Sarit Centre, Nairobi</li>
            <li className="flex items-center gap-2"><Phone className="size-4" /> +254 700 000 000</li>
            <li className="flex items-center gap-2"><Mail className="size-4" /> hello@saritshop.co.ke</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Follow Us</h4>
          <div className="flex gap-3">
            {[Facebook, Twitter, Instagram].map((Icon, i) => (
              <a key={i} href="#" className="size-10 grid place-items-center rounded-full bg-background/10 hover:bg-primary transition-colors">
                <Icon className="size-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-background/10 py-4 text-center text-xs opacity-60">
        © {new Date().getFullYear()} Sarit Shop. All rights reserved.
      </div>
    </footer>
  );
}
