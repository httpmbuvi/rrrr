import { Signal, Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="bg-sidebar text-sidebar-foreground mt-20">
      <div className="container mx-auto px-4 py-14 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-display font-bold text-lg">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-primary">
              <Signal className="h-5 w-5" />
            </span>
            Sarit Shop
          </div>
          <p className="mt-3 text-sm text-sidebar-foreground/70">
            Connecting people everywhere — your trusted Safaricom retail partner at Sarit Centre.
          </p>
          <div className="flex gap-2 mt-4">
            {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
              <a key={i} href="#" className="p-2 rounded-md bg-sidebar-accent hover:bg-primary transition-smooth">
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-semibold mb-3">Quick Links</h4>
          <ul className="space-y-2 text-sm text-sidebar-foreground/80">
            {[
              ["/about", "About Us"],
              ["/services", "Services"],
              ["/team", "Team"],
              ["/events", "Events"],
              ["/contact", "Contact"],
            ].map(([to, l]) => (
              <li key={to}><Link to={to} className="hover:text-primary-glow">{l}</Link></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-3">Services</h4>
          <ul className="space-y-2 text-sm text-sidebar-foreground/80">
            <li>SIM Registration</li>
            <li>M-Pesa Services</li>
            <li>Phone Sales</li>
            <li>WiFi Setup</li>
            <li>Device Repair</li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-3">Get in Touch</h4>
          <ul className="space-y-2 text-sm text-sidebar-foreground/80">
            <li className="flex gap-2"><MapPin className="h-4 w-4 mt-0.5 text-primary-glow" /><span>Sarit Centre, Westlands, Nairobi</span></li>
            <li className="flex gap-2"><Phone className="h-4 w-4 mt-0.5 text-primary-glow" /><span>+254 722 000 000</span></li>
            <li className="flex gap-2"><Mail className="h-4 w-4 mt-0.5 text-primary-glow" /><span>info@saritshop.co.ke</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-sidebar-border">
        <div className="container mx-auto px-4 py-4 text-xs text-sidebar-foreground/60 flex flex-wrap justify-between gap-2">
          <span>© {new Date().getFullYear()} Sarit Shop. All rights reserved.</span>
          <span>Connecting People Everywhere.</span>
        </div>
      </div>
    </footer>
  );
}
