import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { useStore, Slide } from "@/lib/store";

export function HeroSlideshow() {
  const slides = useStore((s) => s.slides);
  const [i, setI] = useState(0);
  const safe: Slide[] = slides.length ? slides : [];

  useEffect(() => {
    if (safe.length < 2) return;
    const t = setInterval(() => setI((x) => (x + 1) % safe.length), 5500);
    return () => clearInterval(t);
  }, [safe.length]);

  if (!safe.length) return null;
  const s = safe[i % safe.length];

  return (
    <section className="relative overflow-hidden h-[78vh] min-h-[520px]">
      {safe.map((sl, idx) => (
        <div
          key={sl.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${idx === i ? "opacity-100" : "opacity-0"}`}
          aria-hidden={idx !== i}
        >
          <img src={sl.image} alt={sl.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/20 dark:from-background/95 dark:via-background/80" />
        </div>
      ))}

      <div className="relative container mx-auto px-4 h-full flex items-center">
        <div key={s.id} className="max-w-xl animate-fade-in-up">
          <h1 className="text-4xl md:text-6xl font-bold leading-tight">
            <span className="text-gradient">{s.title}</span>
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">{s.subtitle}</p>
          {s.ctaLabel && s.ctaHref && (
            <div className="mt-8">
              <Link to={s.ctaHref}>
                <Button size="lg" className="bg-gradient-primary text-primary-foreground shadow-elegant">
                  {s.ctaLabel} <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>

      {safe.length > 1 && (
        <>
          <button
            onClick={() => setI((x) => (x - 1 + safe.length) % safe.length)}
            className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-background/70 hover:bg-background shadow"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={() => setI((x) => (x + 1) % safe.length)}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-background/70 hover:bg-background shadow"
            aria-label="Next slide"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2">
            {safe.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setI(idx)}
                aria-label={`Go to slide ${idx + 1}`}
                className={`h-2 rounded-full transition-all ${idx === i ? "w-8 bg-primary" : "w-2 bg-foreground/30"}`}
              />
            ))}
          </div>
        </>
      )}
    </section>
  );
}
