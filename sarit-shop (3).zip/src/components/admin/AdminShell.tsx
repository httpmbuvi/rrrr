import { ReactNode, useEffect, useState } from "react";
import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, Calendar, MessageSquare, LogOut, Signal, Bell, Search, Moon, Sun, Image as ImageIcon,
} from "lucide-react";
import { actions, useStore } from "@/lib/store";
import { Input } from "@/components/ui/input";

const links = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/slides", label: "Slides", icon: ImageIcon, exact: false },
  { to: "/admin/staff", label: "Staff", icon: Users, exact: false },
  { to: "/admin/events", label: "Events", icon: Calendar, exact: false },
  { to: "/admin/feedback", label: "Feedback", icon: MessageSquare, exact: false },
] as const;

export function AdminShell({ children, title }: { children: ReactNode; title: string }) {
  const path = useRouterState({ select: (r) => r.location.pathname });
  const authed = useStore((s) => s.authed);
  const navigate = useNavigate();
  const [now, setNow] = useState(new Date());
  const [dark, setDark] = useState(false);

  useEffect(() => {
    if (!authed) navigate({ to: "/admin/login" });
  }, [authed, navigate]);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const isDark = localStorage.getItem("theme") === "dark";
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  if (!authed) return null;

  return (
    <div className="min-h-screen flex bg-muted/40">
      <aside className="hidden md:flex flex-col w-64 bg-sidebar text-sidebar-foreground sticky top-0 h-screen">
        <Link to="/" className="flex items-center gap-2 px-5 py-5 border-b border-sidebar-border">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground">
            <Signal className="h-5 w-5" />
          </span>
          <span className="font-display font-bold">Sarit Admin</span>
        </Link>
        <nav className="flex-1 p-3 space-y-1">
          {links.map((l) => {
            const active = l.exact ? path === l.to : path.startsWith(l.to);
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-smooth ${
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-glow"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent"
                }`}
              >
                <l.icon className="h-4 w-4" />
                {l.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <button
            onClick={() => { actions.logout(); navigate({ to: "/admin/login" }); }}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm hover:bg-sidebar-accent"
          >
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur border-b">
          <div className="flex items-center gap-3 px-4 md:px-8 h-16">
            <div>
              <h1 className="font-display font-bold text-lg">{title}</h1>
              <p className="text-xs text-muted-foreground">
                {now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })} · {now.toLocaleTimeString()}
              </p>
            </div>
            <div className="ml-auto hidden sm:flex items-center gap-2 max-w-md flex-1">
              <div className="relative w-full">
                <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search…" className="pl-9 bg-muted/50 border-0" />
              </div>
            </div>
            <button onClick={toggleTheme} className="p-2 rounded-md hover:bg-accent">
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <button className="relative p-2 rounded-md hover:bg-accent">
              <Bell className="h-4 w-4" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-primary" />
            </button>
          </div>
          {/* Mobile nav */}
          <div className="md:hidden flex gap-1 overflow-x-auto px-4 pb-2">
            {links.map((l) => {
              const active = l.exact ? path === l.to : path.startsWith(l.to);
              return (
                <Link key={l.to} to={l.to} className={`text-xs px-3 py-1.5 rounded-md whitespace-nowrap ${active ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                  {l.label}
                </Link>
              );
            })}
          </div>
        </header>
        <main className="flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
