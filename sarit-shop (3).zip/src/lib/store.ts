// Simple in-memory store + localStorage persistence for demo data.
// Replace with Lovable Cloud (Supabase) for real persistence + auth.
import { useSyncExternalStore } from "react";

export type Status = "Online" | "Active" | "Off Duty";
export type Role =
  | "Manager"
  | "Team Leader"
  | "Brand Ambassador"
  | "Staff"
  | "Security";

export interface StaffMember {
  id: string;
  name: string;
  position: string;
  role: Role;
  phone: string;
  email: string;
  status: Status;
  photo: string; // url or data url
  department?: string;
  twitter?: string;
  linkedin?: string;
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  description: string;
  location: string;
}

export interface Feedback {
  id: string;
  name: string;
  message: string;
  rating: number;
  createdAt: string;
  resolved: boolean;
}

export interface Slide {
  id: string;
  image: string; // data url or remote url
  title: string;
  subtitle: string;
  ctaLabel?: string;
  ctaHref?: string;
}

interface AppState {
  staff: StaffMember[];
  events: EventItem[];
  feedback: Feedback[];
  slides: Slide[];
  authed: boolean;
}


const seedStaff = (): StaffMember[] => [
  { id: "1", name: "Grace Wanjiku", position: "Shop Manager", role: "Manager", phone: "+254 712 000 001", email: "grace@saritshop.co.ke", status: "Online", photo: avatarUrl("Grace Wanjiku"), department: "Operations" },
  { id: "2", name: "Brian Otieno", position: "Sales Team Leader", role: "Team Leader", phone: "+254 712 000 002", email: "brian@saritshop.co.ke", status: "Active", photo: avatarUrl("Brian Otieno"), department: "Sales" },
  { id: "3", name: "Linet Achieng", position: "M-Pesa Team Leader", role: "Team Leader", phone: "+254 712 000 003", email: "linet@saritshop.co.ke", status: "Online", photo: avatarUrl("Linet Achieng"), department: "M-Pesa" },
  { id: "4", name: "Kevin Mwangi", position: "Brand Ambassador", role: "Brand Ambassador", phone: "+254 712 000 004", email: "kevin@saritshop.co.ke", status: "Active", photo: avatarUrl("Kevin Mwangi"), department: "Marketing" },
  { id: "5", name: "Aisha Noor", position: "Brand Ambassador", role: "Brand Ambassador", phone: "+254 712 000 005", email: "aisha@saritshop.co.ke", status: "Online", photo: avatarUrl("Aisha Noor"), department: "Marketing" },
  { id: "6", name: "Peter Kamau", position: "Customer Care", role: "Staff", phone: "+254 712 000 006", email: "peter@saritshop.co.ke", status: "Active", photo: avatarUrl("Peter Kamau"), department: "Support" },
  { id: "7", name: "Mary Njeri", position: "SIM Registration", role: "Staff", phone: "+254 712 000 007", email: "mary@saritshop.co.ke", status: "Off Duty", photo: avatarUrl("Mary Njeri"), department: "Registration" },
  { id: "8", name: "James Kiprop", position: "Device Repair", role: "Staff", phone: "+254 712 000 008", email: "james@saritshop.co.ke", status: "Online", photo: avatarUrl("James Kiprop"), department: "Technical" },
  { id: "9", name: "Samuel Mutua", position: "Head of Security", role: "Security", phone: "+254 712 000 009", email: "samuel@saritshop.co.ke", status: "Active", photo: avatarUrl("Samuel Mutua"), department: "Security" },
  { id: "10", name: "Daniel Ouma", position: "Security Officer", role: "Security", phone: "+254 712 000 010", email: "daniel@saritshop.co.ke", status: "Active", photo: avatarUrl("Daniel Ouma"), department: "Security" },
];

function avatarUrl(name: string) {
  const seed = encodeURIComponent(name);
  return `https://api.dicebear.com/9.x/avataaars/svg?seed=${seed}&backgroundColor=b6e3b6,c0e8c0,d1f0d1`;
}

const seedEvents = (): EventItem[] => [
  { id: "e1", title: "Safaricom Twaweza Promo Day", date: "2026-06-12", description: "Customer activation day with exclusive bundles and giveaways.", location: "Sarit Centre, Ground Floor" },
  { id: "e2", title: "Team Building – Karura Forest", date: "2026-07-05", description: "Quarterly team-building activities and outdoor games.", location: "Karura Forest, Nairobi" },
  { id: "e3", title: "M-Pesa Super App Workshop", date: "2026-06-25", description: "Hands-on training for staff on the new Super App features.", location: "Sarit Shop, Training Room" },
];

const seedFeedback = (): Feedback[] => [
  { id: "f1", name: "Anne K.", message: "Excellent M-Pesa service, very quick!", rating: 5, createdAt: new Date().toISOString(), resolved: true },
  { id: "f2", name: "Joseph M.", message: "Staff helped me set up WiFi at home. Thank you!", rating: 5, createdAt: new Date().toISOString(), resolved: false },
  { id: "f3", name: "Lucy W.", message: "Waiting time was a bit long during lunch hours.", rating: 3, createdAt: new Date().toISOString(), resolved: false },
];

const seedSlides = (): Slide[] => [
  {
    id: "s1",
    image: "https://images.unsplash.com/photo-1556656793-08538906a9f8?w=1600&q=80",
    title: "Welcome to Safaricom Sarit Shop",
    subtitle: "Connecting people everywhere — your trusted Safaricom retail partner.",
    ctaLabel: "Explore Services",
    ctaHref: "/services",
  },
  {
    id: "s2",
    image: "https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=1600&q=80",
    title: "M-Pesa Made Simple",
    subtitle: "Deposits, withdrawals, Lipa Na M-Pesa — all in seconds.",
    ctaLabel: "Visit Us",
    ctaHref: "/contact",
  },
  {
    id: "s3",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=1600&q=80",
    title: "Latest Smartphones",
    subtitle: "Genuine devices with flexible payment plans.",
    ctaLabel: "See Phones",
    ctaHref: "/services",
  },
];

const STORAGE_KEY = "sarit-shop-store-v2";

let state: AppState = load();
const listeners = new Set<() => void>();

function load(): AppState {
  const base = { staff: seedStaff(), events: seedEvents(), feedback: seedFeedback(), slides: seedSlides(), authed: false };
  if (typeof window === "undefined") return base;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...base, ...parsed, slides: parsed.slides ?? base.slides };
    }
  } catch {}
  return base;
}


function persist() {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {}
}

function set(updater: (s: AppState) => AppState) {
  state = updater(state);
  persist();
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useStore<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(state),
    () => selector(state),
  );
}

export const actions = {
  addStaff(m: Omit<StaffMember, "id">) {
    set((s) => ({ ...s, staff: [{ ...m, id: crypto.randomUUID() }, ...s.staff] }));
  },
  updateStaff(id: string, patch: Partial<StaffMember>) {
    set((s) => ({ ...s, staff: s.staff.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  },
  removeStaff(id: string) {
    set((s) => ({ ...s, staff: s.staff.filter((x) => x.id !== id) }));
  },
  addEvent(e: Omit<EventItem, "id">) {
    set((s) => ({ ...s, events: [{ ...e, id: crypto.randomUUID() }, ...s.events] }));
  },
  removeEvent(id: string) {
    set((s) => ({ ...s, events: s.events.filter((x) => x.id !== id) }));
  },
  addFeedback(f: Omit<Feedback, "id" | "createdAt" | "resolved">) {
    set((s) => ({
      ...s,
      feedback: [{ ...f, id: crypto.randomUUID(), createdAt: new Date().toISOString(), resolved: false }, ...s.feedback],
    }));
  },
  toggleFeedback(id: string) {
    set((s) => ({ ...s, feedback: s.feedback.map((x) => (x.id === id ? { ...x, resolved: !x.resolved } : x)) }));
  },
  addSlide(sl: Omit<Slide, "id">) {
    set((s) => ({ ...s, slides: [...s.slides, { ...sl, id: crypto.randomUUID() }] }));
  },
  updateSlide(id: string, patch: Partial<Slide>) {
    set((s) => ({ ...s, slides: s.slides.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  },
  removeSlide(id: string) {
    set((s) => ({ ...s, slides: s.slides.filter((x) => x.id !== id) }));
  },
  moveSlide(id: string, dir: -1 | 1) {
    set((s) => {
      const i = s.slides.findIndex((x) => x.id === id);
      if (i < 0) return s;
      const j = i + dir;
      if (j < 0 || j >= s.slides.length) return s;
      const next = [...s.slides];
      [next[i], next[j]] = [next[j], next[i]];
      return { ...s, slides: next };
    });
  },
  login(user: string, pass: string) {
    // Demo only — replace with Lovable Cloud auth.
    if (user === "admin" && pass === "sarit123") {
      set((s) => ({ ...s, authed: true }));
      return true;
    }
    return false;
  },
  logout() {
    set((s) => ({ ...s, authed: false }));
  },
};
