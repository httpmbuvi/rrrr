import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { actions, useStore, Role, Status, StaffMember } from "@/lib/store";
import { Plus, Pencil, Trash2, Search, Download, Upload } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/staff")({
  head: () => ({ meta: [{ title: "Staff — Sarit Admin" }] }),
  component: StaffPage,
});

const ROLES: Role[] = ["Manager", "Team Leader", "Brand Ambassador", "Staff", "Security"];
const STATUSES: Status[] = ["Online", "Active", "Off Duty"];

function StaffPage() {
  const staff = useStore((s) => s.staff);
  const [q, setQ] = useState("");
  const [role, setRole] = useState<string>("all");
  const [editing, setEditing] = useState<StaffMember | null>(null);
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() => staff.filter((s) =>
    (role === "all" || s.role === role) &&
    (s.name.toLowerCase().includes(q.toLowerCase()) || s.position.toLowerCase().includes(q.toLowerCase()))
  ), [staff, q, role]);

  const openNew = () => { setEditing(null); setOpen(true); };
  const openEdit = (m: StaffMember) => { setEditing(m); setOpen(true); };

  const exportCSV = () => {
    const rows = [
      ["Name", "Role", "Position", "Phone", "Email", "Status", "Department"],
      ...staff.map((s) => [s.name, s.role, s.position, s.phone, s.email, s.status, s.department ?? ""]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${(c ?? "").toString().replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "sarit-staff.csv"; a.click();
    URL.revokeObjectURL(url);
    toast.success("Staff report downloaded");
  };

  const printReport = () => {
    window.print();
  };

  return (
    <AdminShell title="Manage Staff">
      <Card className="p-4 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search by name or position…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All roles</SelectItem>
            {ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={exportCSV}><Download className="h-4 w-4 mr-1" /> CSV</Button>
        <Button variant="outline" onClick={printReport}>Print PDF</Button>
        <Button onClick={openNew} className="bg-gradient-primary text-primary-foreground shadow-elegant">
          <Plus className="h-4 w-4 mr-1" /> Add Staff
        </Button>
      </Card>

      <Card className="mt-4 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase">
              <tr>
                <th className="px-4 py-3">Member</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3">Department</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m) => (
                <tr key={m.id} className="border-t hover:bg-muted/30 transition-smooth">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img src={m.photo} alt={m.name} className="h-9 w-9 rounded-full bg-muted object-cover" />
                      <div>
                        <div className="font-medium">{m.name}</div>
                        <div className="text-xs text-muted-foreground">{m.position}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">{m.role}</td>
                  <td className="px-4 py-3">{m.department}</td>
                  <td className="px-4 py-3">
                    <div className="text-xs">{m.phone}</div>
                    <div className="text-xs text-muted-foreground">{m.email}</div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={m.status === "Online" ? "default" : m.status === "Active" ? "secondary" : "outline"}>{m.status}</Badge>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button size="icon" variant="ghost" onClick={() => openEdit(m)}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => { actions.removeStaff(m.id); toast.success("Removed"); }}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))}
              {!filtered.length && (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">No staff found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <StaffDialog open={open} onOpenChange={setOpen} editing={editing} />
    </AdminShell>
  );
}

function StaffDialog({ open, onOpenChange, editing }: { open: boolean; onOpenChange: (o: boolean) => void; editing: StaffMember | null }) {
  const [form, setForm] = useState<Partial<StaffMember>>({});

  // reset when dialog opens
  useEffect(() => {
    if (open) setForm(editing ?? { role: "Staff", status: "Active", photo: "" });
  }, [open, editing]);

  const handlePhoto = (file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, photo: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  const submit = () => {
    if (!form.name?.trim() || !form.position?.trim()) {
      toast.error("Name and position are required");
      return;
    }
    const base: Omit<StaffMember, "id"> = {
      name: form.name!.trim(),
      position: form.position!.trim(),
      role: (form.role as Role) || "Staff",
      status: (form.status as Status) || "Active",
      phone: form.phone || "",
      email: form.email || "",
      department: form.department || "",
      photo: form.photo || `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(form.name!)}`,
    };
    if (editing) {
      actions.updateStaff(editing.id, base);
      toast.success("Staff updated");
    } else {
      actions.addStaff(base);
      toast.success("Staff added");
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader><DialogTitle>{editing ? "Edit staff" : "Add staff"}</DialogTitle></DialogHeader>
        <div className="grid md:grid-cols-2 gap-3">
          <div className="md:col-span-2 flex items-center gap-4">
            <img src={form.photo || "https://api.dicebear.com/9.x/avataaars/svg?seed=new"} className="h-16 w-16 rounded-full bg-muted object-cover" alt="" />
            <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 rounded-md bg-accent hover:bg-primary hover:text-primary-foreground transition-smooth text-sm">
              <Upload className="h-4 w-4" /> Upload photo
              <input type="file" accept="image/*" className="hidden" onChange={(e) => handlePhoto(e.target.files?.[0] ?? null)} />
            </label>
          </div>
          <Field label="Full name"><Input value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Position"><Input value={form.position || ""} onChange={(e) => setForm({ ...form, position: e.target.value })} /></Field>
          <Field label="Role">
            <Select value={form.role || "Staff"} onValueChange={(v) => setForm({ ...form, role: v as Role })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Department"><Input value={form.department || ""} onChange={(e) => setForm({ ...form, department: e.target.value })} /></Field>
          <Field label="Phone"><Input value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          <Field label="Email"><Input type="email" value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label="Status">
            <Select value={form.status || "Active"} onValueChange={(v) => setForm({ ...form, status: v as Status })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} className="bg-gradient-primary text-primary-foreground">{editing ? "Save changes" : "Add staff"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label className="text-xs">{label}</Label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
