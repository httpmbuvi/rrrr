import { createFileRoute } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, Twitter, Linkedin, Facebook } from "lucide-react";
import { Role, useStore, StaffMember } from "@/lib/store";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Team — Sarit Shop" },
      { name: "description", content: "Meet the team behind Safaricom Sarit Shop — managers, team leaders, brand ambassadors, staff and security." },
    ],
  }),
  component: Team,
});

const ORDER: Role[] = ["Manager", "Team Leader", "Brand Ambassador", "Staff", "Security"];

function Team() {
  const staff = useStore((s) => s.staff);

  return (
    <PublicLayout>
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl">
          <span className="text-sm font-semibold text-primary">Our Team</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold">Hierarchy & people behind Sarit Shop</h1>
          <p className="mt-4 text-muted-foreground">A clear structure built around customers — from leadership to security.</p>
        </div>

        <div className="mt-12 space-y-14">
          {ORDER.map((role) => {
            const group = staff.filter((s) => s.role === role);
            if (!group.length) return null;
            return (
              <div key={role}>
                <div className="flex items-center gap-3 mb-6">
                  <div className="h-px flex-1 bg-border" />
                  <h2 className="text-xl md:text-2xl font-bold">{role}s</h2>
                  <div className="h-px flex-1 bg-border" />
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {group.map((m) => <MemberCard key={m.id} m={m} />)}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </PublicLayout>
  );
}

function MemberCard({ m }: { m: StaffMember }) {
  const statusColor =
    m.status === "Online" ? "bg-success text-white" :
    m.status === "Active" ? "bg-primary text-primary-foreground" :
    "bg-muted text-muted-foreground";

  return (
    <Card className="p-6 hover-lift glass relative overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-20 bg-gradient-primary opacity-90" />
      <div className="relative flex flex-col items-center text-center pt-4">
        <img
          src={m.photo}
          alt={m.name}
          className="h-24 w-24 rounded-full ring-4 ring-card object-cover bg-muted"
          loading="lazy"
        />
        <h3 className="mt-3 font-bold text-lg">{m.name}</h3>
        <p className="text-sm text-primary font-medium">{m.position}</p>
        <Badge className={`mt-2 ${statusColor}`}>{m.status}</Badge>
        <div className="mt-4 w-full space-y-1 text-sm text-muted-foreground">
          <p className="flex items-center gap-2 justify-center"><Phone className="h-3.5 w-3.5" /> {m.phone}</p>
          <p className="flex items-center gap-2 justify-center"><Mail className="h-3.5 w-3.5" /> {m.email}</p>
        </div>
        <div className="mt-4 flex gap-2">
          {[Twitter, Linkedin, Facebook].map((Icon, i) => (
            <a key={i} href="#" className="p-2 rounded-md bg-accent text-primary hover:bg-primary hover:text-primary-foreground transition-smooth">
              <Icon className="h-3.5 w-3.5" />
            </a>
          ))}
        </div>
      </div>
    </Card>
  );
}
