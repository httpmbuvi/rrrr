import { createFileRoute } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Card } from "@/components/ui/card";
import { IdCard, CreditCard, Smartphone, Headphones, Wifi, Wrench, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Sarit Shop" },
      { name: "description", content: "Safaricom services at Sarit Shop: SIM registration, M-Pesa, phone sales, WiFi, customer care and device repair." },
    ],
  }),
  component: Services,
});

const services = [
  { icon: IdCard, title: "SIM Registration", points: ["New line activation", "SIM swap & replacement", "KYC verification"] },
  { icon: CreditCard, title: "M-Pesa Services", points: ["Deposits & withdrawals", "Lipa Na M-Pesa", "Agent support"] },
  { icon: Smartphone, title: "Phone Sales", points: ["Latest smartphones", "Flexible payment plans", "Trade-in available"] },
  { icon: Headphones, title: "Customer Care", points: ["Billing & plans", "Account assistance", "Tariff advice"] },
  { icon: Wifi, title: "WiFi Setup", points: ["Home & business fibre", "Router installation", "Network support"] },
  { icon: Wrench, title: "Device Repair", points: ["Free diagnostics", "Authorised repairs", "Genuine parts"] },
];

function Services() {
  return (
    <PublicLayout>
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl">
          <span className="text-sm font-semibold text-primary">Services</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold">Everything Safaricom, under one roof.</h1>
          <p className="mt-4 text-muted-foreground">Walk in for fast, professional service from our certified team.</p>
        </div>
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s) => (
            <Card key={s.title} className="p-7 hover-lift">
              <div className="inline-flex p-3 rounded-xl bg-gradient-primary text-primary-foreground shadow-glow">
                <s.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-xl font-bold">{s.title}</h3>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                {s.points.map((p) => (
                  <li key={p} className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary mt-0.5" /> {p}
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </section>
    </PublicLayout>
  );
}
