import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { Card } from "@/components/ui/card";
import { useStore } from "@/lib/store";
import { Users, Calendar, MessageSquare, TrendingUp, Activity, Package, DollarSign, BarChart3 } from "lucide-react";
import { Counter } from "@/components/site/Counter";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Dashboard — Sarit Admin" }] }),
  component: Dashboard,
});

function Dashboard() {
  const staff = useStore((s) => s.staff);
  const events = useStore((s) => s.events);
  const feedback = useStore((s) => s.feedback);

  const online = staff.filter((s) => s.status === "Online").length;
  const unresolved = feedback.filter((f) => !f.resolved).length;

  const stats = [
    { icon: Users, label: "Total Staff", value: staff.length, sub: `${online} online` },
    { icon: Calendar, label: "Upcoming Events", value: events.length, sub: "this quarter" },
    { icon: MessageSquare, label: "Open Feedback", value: unresolved, sub: `${feedback.length} total` },
    { icon: TrendingUp, label: "Monthly Target", value: 97, sub: "% achieved", suffix: "%" },
  ];

  const sales = [
    { label: "SIM Registration", value: 124, color: "bg-primary" },
    { label: "M-Pesa Transactions", value: 489, color: "bg-success" },
    { label: "Phone Sales", value: 18, color: "bg-warning" },
    { label: "WiFi Setups", value: 7, color: "bg-accent-foreground" },
  ];
  const maxSale = Math.max(...sales.map((s) => s.value));

  return (
    <AdminShell title="Dashboard Overview">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.label} className="p-5 hover-lift">
            <div className="flex items-center justify-between">
              <div className="p-2.5 rounded-lg bg-gradient-primary text-primary-foreground">
                <s.icon className="h-4 w-4" />
              </div>
              <span className="text-xs text-muted-foreground">{s.sub}</span>
            </div>
            <div className="mt-3 text-2xl font-bold"><Counter to={s.value} suffix={s.suffix ?? ""} /></div>
            <div className="text-sm text-muted-foreground">{s.label}</div>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-bold">Daily Sales Summary</h2>
              <p className="text-xs text-muted-foreground">Today, by service</p>
            </div>
            <BarChart3 className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="space-y-4">
            {sales.map((s) => (
              <div key={s.label}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">{s.label}</span>
                  <span className="text-muted-foreground">{s.value}</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div className={`h-full ${s.color} transition-all`} style={{ width: `${(s.value / maxSale) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="font-bold mb-4">Announcements</h2>
          <ul className="space-y-3 text-sm">
            <li className="flex gap-3 p-3 rounded-lg bg-accent">
              <Activity className="h-4 w-4 text-primary mt-0.5" />
              <div>
                <p className="font-medium">Twaweza Day</p>
                <p className="text-xs text-muted-foreground">All staff briefing at 8:30am</p>
              </div>
            </li>
            <li className="flex gap-3 p-3 rounded-lg bg-muted">
              <Package className="h-4 w-4 text-primary mt-0.5" />
              <div>
                <p className="font-medium">New stock arrived</p>
                <p className="text-xs text-muted-foreground">Samsung A16 & Neon Smarta available</p>
              </div>
            </li>
            <li className="flex gap-3 p-3 rounded-lg bg-muted">
              <DollarSign className="h-4 w-4 text-primary mt-0.5" />
              <div>
                <p className="font-medium">Cash float</p>
                <p className="text-xs text-muted-foreground">Top up before opening</p>
              </div>
            </li>
          </ul>
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <h2 className="font-bold mb-4">Inventory Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { name: "SIM Cards", qty: 320 },
            { name: "Smartphones", qty: 48 },
            { name: "Routers", qty: 22 },
            { name: "Accessories", qty: 156 },
          ].map((i) => (
            <div key={i.name} className="p-4 rounded-xl bg-muted/60">
              <div className="text-xs text-muted-foreground">{i.name}</div>
              <div className="text-2xl font-bold mt-1">{i.qty}</div>
            </div>
          ))}
        </div>
      </Card>
    </AdminShell>
  );
}
