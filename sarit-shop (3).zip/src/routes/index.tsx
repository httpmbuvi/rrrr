import { createFileRoute, Link } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Counter } from "@/components/site/Counter";
import { HeroSlideshow } from "@/components/site/HeroSlideshow";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Smartphone, CreditCard, Headphones, Wifi, Wrench, IdCard,
  Users, Trophy, Activity, Target,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sarit Shop — Safaricom Retail at Sarit Centre" },
      { name: "description", content: "Welcome to Safaricom Sarit Shop. SIM registration, M-Pesa, phone sales, WiFi setup, repair and customer care at Sarit Centre, Nairobi." },
      { property: "og:title", content: "Sarit Shop — Safaricom Retail at Sarit Centre" },
      { property: "og:description", content: "Connecting people everywhere. Visit Sarit Shop at Sarit Centre for all Safaricom services." },
    ],
  }),
  component: Home,
});

const services = [
  { icon: IdCard, title: "SIM Registration", desc: "New lines, swaps, and KYC in minutes." },
  { icon: CreditCard, title: "M-Pesa Services", desc: "Deposits, withdrawals, agent and Lipa Na M-Pesa." },
  { icon: Smartphone, title: "Phone Sales", desc: "Genuine smartphones with flexible payment plans." },
  { icon: Headphones, title: "Customer Care", desc: "Friendly support for billing, plans and queries." },
  { icon: Wifi, title: "WiFi Setup", desc: "Home and business fibre installation & support." },
  { icon: Wrench, title: "Device Repair", desc: "Quick diagnostics and authorised repairs." },
];

function Home() {
  return (
    <PublicLayout>
      <HeroSlideshow />


      {/* Stats */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: Users, label: "Number of Staff", value: 24, suffix: "+" },
            { icon: Trophy, label: "Customers Served", value: 18500, suffix: "+" },
            { icon: Activity, label: "Active Services", value: 12, suffix: "" },
            { icon: Target, label: "Monthly Targets Hit", value: 97, suffix: "%" },
          ].map((s) => (
            <Card key={s.label} className="p-6 hover-lift border-0 shadow-card">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-xl bg-gradient-primary text-primary-foreground shadow-glow">
                  <s.icon className="h-5 w-5" />
                </div>
              </div>
              <div className="mt-4 text-3xl font-bold font-display">
                <Counter to={s.value} suffix={s.suffix} />
              </div>
              <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
            </Card>
          ))}
        </div>
      </section>

      {/* Services */}
      <section className="container mx-auto px-4 py-12">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold">Featured Services</h2>
          <p className="mt-3 text-muted-foreground">Everything you need from Safaricom — fast, friendly, and right here at Sarit Centre.</p>
        </div>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <Card key={s.title} className="p-6 hover-lift border bg-card animate-fade-in-up" style={{ animationDelay: `${i * 60}ms` }}>
              <div className="inline-flex p-3 rounded-xl bg-accent text-primary">
                <s.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{s.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-20">
        <div className="rounded-3xl bg-gradient-hero text-primary-foreground p-10 md:p-16 shadow-elegant overflow-hidden relative">
          <div className="absolute -right-12 -top-12 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          <h3 className="text-3xl md:text-4xl font-bold max-w-xl">Meet our team and discover what makes us different.</h3>
          <p className="mt-3 max-w-lg opacity-90">A passionate team committed to making your Safaricom experience effortless.</p>
          <div className="mt-6 flex gap-3 flex-wrap">
            <Link to="/team"><Button size="lg" variant="secondary">View Team</Button></Link>
            <Link to="/events"><Button size="lg" variant="outline" className="bg-transparent border-white/40 text-white hover:bg-white/10">See Events</Button></Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
