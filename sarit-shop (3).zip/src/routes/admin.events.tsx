import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { actions, useStore } from "@/lib/store";
import { Calendar, MapPin, Trash2, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/events")({
  head: () => ({ meta: [{ title: "Events — Sarit Admin" }] }),
  component: EventsPage,
});

function EventsPage() {
  const events = useStore((s) => s.events);
  const [f, setF] = useState({ title: "", date: "", location: "", description: "" });

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.title || !f.date) { toast.error("Title and date required"); return; }
    actions.addEvent(f);
    setF({ title: "", date: "", location: "", description: "" });
    toast.success("Event added");
  };

  return (
    <AdminShell title="Manage Events">
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-6 lg:col-span-1">
          <h2 className="font-bold mb-4 flex items-center gap-2"><Plus className="h-4 w-4" /> New event</h2>
          <form onSubmit={add} className="space-y-3">
            <div><Label>Title</Label><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
            <div><Label>Date</Label><Input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></div>
            <div><Label>Location</Label><Input value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></div>
            <div><Label>Description</Label><Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
            <Button type="submit" className="w-full bg-gradient-primary text-primary-foreground">Add event</Button>
          </form>
        </Card>

        <div className="lg:col-span-2 grid sm:grid-cols-2 gap-4">
          {events.map((e) => (
            <Card key={e.id} className="p-5 hover-lift">
              <div className="text-xs inline-flex items-center gap-1.5 px-2 py-1 rounded bg-accent text-primary font-semibold">
                <Calendar className="h-3 w-3" /> {new Date(e.date).toLocaleDateString()}
              </div>
              <h3 className="mt-2 font-bold">{e.title}</h3>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1"><MapPin className="h-3 w-3" /> {e.location}</p>
              <p className="mt-2 text-sm text-muted-foreground">{e.description}</p>
              <Button size="sm" variant="ghost" className="mt-3 text-destructive" onClick={() => { actions.removeEvent(e.id); toast.success("Removed"); }}>
                <Trash2 className="h-4 w-4 mr-1" /> Delete
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </AdminShell>
  );
}
