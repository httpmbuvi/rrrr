import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { actions, useStore } from "@/lib/store";
import { Star, CheckCircle2, Circle } from "lucide-react";

export const Route = createFileRoute("/admin/feedback")({
  head: () => ({ meta: [{ title: "Feedback — Sarit Admin" }] }),
  component: FeedbackPage,
});

function FeedbackPage() {
  const feedback = useStore((s) => s.feedback);

  return (
    <AdminShell title="Customer Feedback">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {feedback.map((f) => (
          <Card key={f.id} className="p-5">
            <div className="flex items-center justify-between">
              <div className="font-bold">{f.name}</div>
              <Badge variant={f.resolved ? "default" : "secondary"}>{f.resolved ? "Resolved" : "Open"}</Badge>
            </div>
            <div className="flex gap-0.5 mt-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-3.5 w-3.5 ${i < f.rating ? "fill-warning text-warning" : "text-muted-foreground"}`} />
              ))}
            </div>
            <p className="mt-3 text-sm text-muted-foreground">{f.message}</p>
            <div className="mt-3 text-xs text-muted-foreground">{new Date(f.createdAt).toLocaleString()}</div>
            <Button size="sm" variant="ghost" className="mt-2" onClick={() => actions.toggleFeedback(f.id)}>
              {f.resolved ? <Circle className="h-4 w-4 mr-1" /> : <CheckCircle2 className="h-4 w-4 mr-1 text-success" />}
              {f.resolved ? "Mark open" : "Mark resolved"}
            </Button>
          </Card>
        ))}
        {!feedback.length && <p className="text-muted-foreground">No feedback yet.</p>}
      </div>
    </AdminShell>
  );
}
