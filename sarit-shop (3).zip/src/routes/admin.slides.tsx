import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { actions, useStore, Slide } from "@/lib/store";
import { Plus, Pencil, Trash2, Upload, ArrowUp, ArrowDown } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/slides")({
  head: () => ({ meta: [{ title: "Slides — Sarit Admin" }] }),
  component: SlidesPage,
});

function SlidesPage() {
  const slides = useStore((s) => s.slides);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Slide | null>(null);

  return (
    <AdminShell title="Homepage Slideshow">
      <Card className="p-4 flex justify-between items-center">
        <p className="text-sm text-muted-foreground">Add, edit, reorder, or remove slides that appear on the homepage hero.</p>
        <Button onClick={() => { setEditing(null); setOpen(true); }} className="bg-gradient-primary text-primary-foreground">
          <Plus className="h-4 w-4 mr-1" /> Add Slide
        </Button>
      </Card>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
        {slides.map((s, idx) => (
          <Card key={s.id} className="overflow-hidden hover-lift">
            <div className="relative h-40 bg-muted">
              <img src={s.image} alt={s.title} className="w-full h-full object-cover" />
              <span className="absolute top-2 left-2 text-xs bg-background/90 px-2 py-0.5 rounded">#{idx + 1}</span>
            </div>
            <div className="p-4">
              <h3 className="font-semibold truncate">{s.title}</h3>
              <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{s.subtitle}</p>
              <div className="flex justify-between mt-3">
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => actions.moveSlide(s.id, -1)} disabled={idx === 0}>
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => actions.moveSlide(s.id, 1)} disabled={idx === slides.length - 1}>
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(s); setOpen(true); }}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => { actions.removeSlide(s.id); toast.success("Slide removed"); }}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
        {!slides.length && (
          <Card className="p-10 text-center text-muted-foreground md:col-span-2 lg:col-span-3">
            No slides yet. Click "Add Slide" to create one.
          </Card>
        )}
      </div>

      <SlideDialog open={open} onOpenChange={setOpen} editing={editing} />
    </AdminShell>
  );
}

function SlideDialog({ open, onOpenChange, editing }: { open: boolean; onOpenChange: (o: boolean) => void; editing: Slide | null }) {
  const [form, setForm] = useState<Partial<Slide>>({});

  useEffect(() => {
    if (open) setForm(editing ?? { title: "", subtitle: "", image: "", ctaLabel: "", ctaHref: "/" });
  }, [open, editing]);

  const handleImage = (file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, image: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  const submit = () => {
    if (!form.title?.trim() || !form.image) {
      toast.error("Title and image are required");
      return;
    }
    const data: Omit<Slide, "id"> = {
      title: form.title.trim(),
      subtitle: form.subtitle?.trim() || "",
      image: form.image,
      ctaLabel: form.ctaLabel || "",
      ctaHref: form.ctaHref || "/",
    };
    if (editing) {
      actions.updateSlide(editing.id, data);
      toast.success("Slide updated");
    } else {
      actions.addSlide(data);
      toast.success("Slide added");
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{editing ? "Edit slide" : "Add slide"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Image</Label>
            <div className="mt-1 flex items-center gap-3">
              {form.image ? (
                <img src={form.image} alt="" className="h-16 w-24 object-cover rounded border" />
              ) : (
                <div className="h-16 w-24 rounded border bg-muted" />
              )}
              <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 rounded-md bg-accent hover:bg-primary hover:text-primary-foreground text-sm">
                <Upload className="h-4 w-4" /> Upload
                <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImage(e.target.files?.[0] ?? null)} />
              </label>
            </div>
            <Input className="mt-2" placeholder="or paste image URL" value={form.image || ""} onChange={(e) => setForm({ ...form, image: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Title</Label>
            <Input value={form.title || ""} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Subtitle</Label>
            <Input value={form.subtitle || ""} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">CTA Label</Label>
              <Input value={form.ctaLabel || ""} onChange={(e) => setForm({ ...form, ctaLabel: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs">CTA Link</Label>
              <Input value={form.ctaHref || ""} onChange={(e) => setForm({ ...form, ctaHref: e.target.value })} placeholder="/services" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} className="bg-gradient-primary text-primary-foreground">{editing ? "Save changes" : "Add slide"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
