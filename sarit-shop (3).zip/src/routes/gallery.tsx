import { createFileRoute } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Sarit Shop" },
      { name: "description", content: "Photos from Sarit Shop — promotions, team activities and customer experiences." },
    ],
  }),
  component: Gallery,
});

const photos = [
  "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1556740758-90de374c12ad?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=900&q=70",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=900&q=70",
];

function Gallery() {
  return (
    <PublicLayout>
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl">
          <span className="text-sm font-semibold text-primary">Gallery</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold">Moments from Sarit Shop</h1>
          <p className="mt-4 text-muted-foreground">Promotions, team-building, customer experiences and behind-the-scenes.</p>
        </div>
        <div className="mt-12 columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
          {photos.map((src, i) => (
            <div key={i} className="break-inside-avoid overflow-hidden rounded-2xl shadow-card group">
              <img
                src={src}
                alt={`Gallery image ${i + 1}`}
                loading="lazy"
                className="w-full h-auto group-hover:scale-105 transition-smooth"
              />
            </div>
          ))}
        </div>
      </section>
    </PublicLayout>
  );
}
