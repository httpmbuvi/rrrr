import { createFileRoute } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Card } from "@/components/ui/card";
import { Award, Heart, Rocket, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Sarit Shop" },
      { name: "description", content: "Learn about Safaricom Sarit Shop, our story, mission and values at Sarit Centre, Westlands." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <PublicLayout>
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl">
          <span className="text-sm font-semibold text-primary">About Us</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold">Connecting people, building communities.</h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Sarit Shop is an authorised Safaricom retail outlet at Sarit Centre, Westlands. We bring world-class telecommunication services to your doorstep — from M-Pesa and SIM registration to fibre and the latest smartphones.
          </p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 gap-8 items-start">
          <Card className="p-8 hover-lift">
            <h2 className="text-2xl font-bold">Our Mission</h2>
            <p className="mt-3 text-muted-foreground">To transform lives by providing reliable, accessible Safaricom services with the warmth and professionalism our customers deserve.</p>
          </Card>
          <Card className="p-8 hover-lift">
            <h2 className="text-2xl font-bold">Our Vision</h2>
            <p className="mt-3 text-muted-foreground">To be the most trusted Safaricom retail experience in Kenya — every visit, every time.</p>
          </Card>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { icon: Heart, t: "Customer First", d: "We listen, care and serve with empathy." },
            { icon: ShieldCheck, t: "Integrity", d: "Trustworthy service in every interaction." },
            { icon: Rocket, t: "Innovation", d: "Always exploring better ways to serve." },
            { icon: Award, t: "Excellence", d: "Quality is the standard, not the goal." },
          ].map((v) => (
            <Card key={v.t} className="p-6 hover-lift">
              <div className="inline-flex p-3 rounded-xl bg-accent text-primary"><v.icon className="h-5 w-5" /></div>
              <h3 className="mt-3 font-semibold">{v.t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{v.d}</p>
            </Card>
          ))}
        </div>
      </section>
    </PublicLayout>
  );
}
