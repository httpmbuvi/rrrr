import { createFileRoute } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useState } from "react";
import { actions } from "@/lib/store";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Sarit Shop" },
      { name: "description", content: "Visit Sarit Shop at Sarit Centre, Westlands. Phone, email, hours and contact form." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.message.trim()) {
      toast.error("Please enter your name and message.");
      return;
    }
    actions.addFeedback({ name: form.name.trim(), message: form.message.trim(), rating: 5 });
    toast.success("Thank you! We'll get back to you shortly.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <PublicLayout>
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl">
          <span className="text-sm font-semibold text-primary">Contact</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold">Visit us at Sarit Centre</h1>
          <p className="mt-4 text-muted-foreground">We're here to help — drop by, call, or send a message.</p>
        </div>

        <div className="mt-12 grid lg:grid-cols-2 gap-8">
          <Card className="p-7">
            <h2 className="text-xl font-bold mb-4">Send us a message</h2>
            <form onSubmit={submit} className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={80} />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} maxLength={120} />
              </div>
              <div>
                <Label htmlFor="msg">Message</Label>
                <Textarea id="msg" rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} maxLength={1000} />
              </div>
              <Button type="submit" className="bg-gradient-primary text-primary-foreground shadow-elegant w-full">Send Message</Button>
            </form>
          </Card>

          <div className="space-y-5">
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">Get in touch</h2>
              <ul className="space-y-3 text-sm">
                <li className="flex gap-3"><MapPin className="h-5 w-5 text-primary" /> Sarit Centre, Westlands, Nairobi</li>
                <li className="flex gap-3"><Phone className="h-5 w-5 text-primary" /> +254 722 000 000</li>
                <li className="flex gap-3"><Mail className="h-5 w-5 text-primary" /> info@saritshop.co.ke</li>
                <li className="flex gap-3"><Clock className="h-5 w-5 text-primary" /> Mon–Sat 8:00–20:00 · Sun 10:00–18:00</li>
              </ul>
            </Card>
            <Card className="overflow-hidden">
              <iframe
                title="Sarit Centre location"
                src="https://www.google.com/maps?q=Sarit+Centre+Westlands+Nairobi&output=embed"
                className="w-full h-80 border-0"
                loading="lazy"
              />
            </Card>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
