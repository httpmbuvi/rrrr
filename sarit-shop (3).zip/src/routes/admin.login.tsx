import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Signal, ShieldCheck } from "lucide-react";
import { actions, useStore } from "@/lib/store";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/login")({
  head: () => ({ meta: [{ title: "Admin Login — Sarit Shop" }] }),
  component: Login,
});

function Login() {
  const [user, setUser] = useState("admin");
  const [pass, setPass] = useState("");
  const navigate = useNavigate();
  const authed = useStore((s) => s.authed);

  useEffect(() => {
    if (authed) navigate({ to: "/admin" });
  }, [authed, navigate]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (actions.login(user.trim(), pass)) {
      toast.success("Welcome back!");
      navigate({ to: "/admin" });
    } else {
      toast.error("Invalid credentials. Try admin / sarit123");
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-hero text-primary-foreground relative overflow-hidden">
        <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
        <div className="flex items-center gap-2 font-display font-bold text-xl">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-white/15">
            <Signal className="h-5 w-5" />
          </span>
          Sarit Shop
        </div>
        <div className="relative">
          <h2 className="text-4xl font-bold">Manage your shop with ease.</h2>
          <p className="mt-3 opacity-90 max-w-md">Staff, events, inventory and feedback — all in one dashboard.</p>
        </div>
        <div className="text-xs opacity-70 flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5" /> Secure admin area</div>
      </div>

      <div className="flex items-center justify-center p-6">
        <Card className="w-full max-w-md p-8 shadow-elegant">
          <h1 className="text-2xl font-bold">Admin Login</h1>
          <p className="text-sm text-muted-foreground mt-1">Demo credentials: <code className="text-primary">admin / sarit123</code></p>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <Label htmlFor="user">Username</Label>
              <Input id="user" value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" />
            </div>
            <div>
              <Label htmlFor="pass">Password</Label>
              <Input id="pass" type="password" value={pass} onChange={(e) => setPass(e.target.value)} autoComplete="current-password" />
            </div>
            <Button type="submit" className="w-full bg-gradient-primary text-primary-foreground shadow-elegant">
              Sign in
            </Button>
          </form>
          <p className="text-xs text-muted-foreground mt-6">
            For production-grade authentication, database and file uploads, enable Lovable Cloud.
          </p>
        </Card>
      </div>
    </div>
  );
}
