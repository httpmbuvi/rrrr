import { createFileRoute } from "@tanstack/react-router";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Card } from "@/components/ui/card";
import { Calendar, MapPin } from "lucide-react";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: "Events — Sarit Shop" },
      { name: "description", content: "Upcoming events, team activities and Safaricom promotions at Sarit Shop." },
    ],
  }),
  component: Events,
});

function Events() {
  const events = useStore((s) => s.events);
  return (
    <PublicLayout>
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl">
          <span className="text-sm font-semibold text-primary">Events</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold">Upcoming events & activities</h1>
          <p className="mt-4 text-muted-foreground">From Safaricom promotions to team-building, here's what's happening.</p>
        </div>
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {events.map((e) => (
            <Card key={e.id} className="p-6 hover-lift">
              <div className="text-xs font-semibold inline-flex items-center gap-2 px-2 py-1 rounded-md bg-accent text-primary">
                <Calendar className="h-3 w-3" /> {new Date(e.date).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}
              </div>
              <h3 className="mt-3 text-lg font-bold">{e.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{e.description}</p>
              <p className="mt-3 text-xs text-muted-foreground flex items-center gap-2"><MapPin className="h-3.5 w-3.5" /> {e.location}</p>
            </Card>
          ))}
        </div>
      </section>
    </PublicLayout>
  );
}
